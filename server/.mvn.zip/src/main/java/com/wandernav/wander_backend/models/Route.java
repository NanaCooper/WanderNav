package com.wandernav.wander_backend.models;

import jakarta.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
public class Route {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(length = 500)
    private String description;

    @ManyToMany
    @JoinTable(
        name = "route_locations",
        joinColumns = @JoinColumn(name = "route_id"),
        inverseJoinColumns = @JoinColumn(name = "location_id")
    )
    private List<Location> locations;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public Route() {}

    public Route(String name, String description, List<Location> locations, User user) {
        this.name = name;
        this.description = description;
        this.locations = locations;
        this.user = user;
    }

    public Long getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public List<Location> getLocations() { return locations; }
    public void setLocations(List<Location> locations) { this.locations = locations; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
