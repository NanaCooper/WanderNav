package com.wandernav.wander_backend.repositories;

import com.wandernav.wander_backend.models.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Long> {
}
