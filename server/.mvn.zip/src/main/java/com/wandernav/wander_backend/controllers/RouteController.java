package com.wandernav.wander_backend.controllers;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.wandernav.wander_backend.models.Location;
import com.wandernav.wander_backend.models.Route;
import com.wandernav.wander_backend.models.User;
import com.wandernav.wander_backend.repositories.LocationRepository;
import com.wandernav.wander_backend.repositories.RouteRepository;
import com.wandernav.wander_backend.repositories.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api/routes")
@Tag(name = "Routes", description = "Manage routes composed of locations")
public class RouteController {

    @Autowired
    private RouteRepository routeRepository;

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private UserRepository userRepository;

    @Operation(summary = "Get all routes")
    @GetMapping
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    @Operation(summary = "Get route by ID")
    @GetMapping("/{id}")
    public ResponseEntity<Route> getRouteById(@PathVariable Long id) {
        return routeRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Get all routes for the logged-in user")
    @GetMapping("/user/me")
    public ResponseEntity<List<Route>> getRoutesForCurrentUser() {
        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        User currentUser = userRepository.findByUsername(currentUsername)
                .orElseThrow(() -> new RuntimeException("User not found."));

        List<Route> userRoutes = routeRepository.findAll().stream()
                .filter(route -> route.getUser() != null && route.getUser().getId().equals(currentUser.getId()))
                .toList();

        return ResponseEntity.ok(userRoutes);
    }

    @Operation(summary = "Create a new route with location IDs")
    @PostMapping
    public ResponseEntity<Route> createRoute(@RequestBody Route route) {
        // Get current logged-in user
        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        User currentUser = userRepository.findByUsername(currentUsername)
                .orElseThrow(() -> new RuntimeException("User not found."));

        // Set the user to the route
        route.setUser(currentUser);

        // Resolve full location objects by their IDs
        List<Location> fullLocations = route.getLocations().stream()
                .map(loc -> locationRepository.findById(loc.getId()).orElse(null))
                .filter(Objects::nonNull)
                .toList();

        route.setLocations(fullLocations);
        return ResponseEntity.ok(routeRepository.save(route));
    }

    @Operation(summary = "Delete a route")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteRoute(@PathVariable Long id) {
    Route route = routeRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Route not found"));

    String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();

    if (!route.getUser().getUsername().equals(currentUsername)) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. This route doesn't belong to you.");
    }

    routeRepository.delete(route);
    return ResponseEntity.ok("Route deleted successfully.");
   }

}