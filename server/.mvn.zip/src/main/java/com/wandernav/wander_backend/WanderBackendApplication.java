package com.wandernav.wander_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WanderBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(WanderBackendApplication.class, args);
	}

}
